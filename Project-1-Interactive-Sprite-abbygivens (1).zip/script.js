/**
 * Project 1 - Interactive Image
 * Name: Abigail Givens
 * Completion Date: June 25th, 2022
 * Basic Description of Image: A shocked flower
 * Basic Description of Interactions: When pressing the mouse, you will notice that the flower waves goodbye as she gets sucked into the abyss.
*/
/*

Basic description of the image;
Basic description of user interactions to expect;
Citations of any code sources used for reference;
*/



function setup(){
  createCanvas(600, 400); //size of canvas
  xSpeed = random(-2, 2);
  ySpeed = random (-2, 2);
  rSpeed = random (-.05, -.05);
}

var x = 0;
var y = 0;
var r = 0;
var s = 1;
var xSpeed = 0;
var ySpeed = 0;
var rSpeed = 0;

function draw(){
 background(0); //black background
translate(x, y);
rotate(r);
  r += .05;
  s = y/height;
  scale(s);
  x += xSpeed;
  if(x > width || x < 0) {
    xSpeed *= -1;
  }
y += ySpeed;
  if(y > height || y < 0) {
    ySpeed *= -1;
  }
  
  noStroke(); //no outline
//** Step 1-Stem & Stem Leafs *//
  fill(91, 163, 92); //#5BA35C fill
  rect(290, 150, 20, 200); //stem
  ellipse(270, 300, 50, 20); //left stem leaf
  
//* Step 2-Leafs *//
  fill(255, 183, 233); //#FFB7E9 fill
  ellipse(300, 100, 50, 80); //top leaf
  ellipse(350, 150, 80, 50); //right leaf
  ellipse(300, 200, 50, 80); //bottom leaf
  ellipse(250, 150, 80, 50); //left leaf
  
//** Step 3-Head/Middle of Flower *//
  fill(252, 255, 191); //#FCFFBF fill
  ellipse(300, 150, 65, 65); //head-middle of flower

//* Step 5a- Outline of Eyes */
  fill(0); //black fill
  ellipse(280, 150, 12, 12); //left eye
  ellipse(320, 150, 12, 12); //right eye
  
//* Step 5b-Eyes */
  fill(255); //white fill
  ellipse(280, 150, 10, 10); //left eye
  ellipse(320, 150, 10, 10); //right eye
  
//* Step 5c-Pupils */
  fill(0); //black fill
  ellipse(280, 150, 6, 6); //left eye
  ellipse(320, 150, 6, 6); //right eye 
  
//* Step 6a-Mouth */
  fill(0); //black fill
  arc(300, 170, 22, 22, PI, 0); //frowning face
  
//* Step 6b-Tounge */
  fill(232, 98, 98); //#E86262 fill
  arc(300, 170, 15, 15, PI, 0); //tounge

if (mouseIsPressed) {
  fill(91, 163, 92);
  ellipse(334, 240, 20, 50); //leaf up wave
  rect(330, 245, 9, 40); //arm
  rect(295, 285, 44, 9); //bicept
    
} else {
  fill(91, 163, 92);
  ellipse(350, 250, 50, 20); //leaf down wave
  rect(330, 245, 9, 40); //arm
  rect(295, 285, 44, 9); //bicept
  }

}